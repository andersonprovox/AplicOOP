/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

/**
 *
 * @author carmo
 */
public class carroCaro {
    private double valorCarro;
    private double valorImposto;
    private double valor_venda;
    private double valor_total;
    
    public void recNum( double custoFab){
        this.valorCarro = custoFab;
    }
    public double imposto(){
        this.valorImposto = this.valorCarro * 0.45;
        return this.valorImposto;
    }
    public double valorVenda(){
        this.valor_venda = this.valorCarro* 0.12;
        return this.valor_venda;
    }
    public double total(){
        this.valorImposto = this.valorCarro * 0.45;
        this.valor_venda = this.valorCarro* 0.12;
        this.valor_total = this.valor_venda + this.valorImposto + this.valorCarro;
        return this.valor_total;
    }

}