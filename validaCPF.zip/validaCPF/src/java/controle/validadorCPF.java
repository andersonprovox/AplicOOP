/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

/**
 *
 * @author ander
 */
public class validadorCPF {
    private int n1, n2, n3, n4, n5, n6, n7, n8, n9, d10, d11;
    private int resto;
    private int decseg, decpri;
    private int multinum, sm;
    private String valido, invalido;
    
    public void recNum(int num1, int num2, int num3, int num4, 
            int num5, int num6, int num7, int num8, int num9, int dig10, int dig11){
        this.n1 = num1;
        this.n2 = num2;
        this.n3 = num3;
        this.n4 = num4;
        this.n5 = num5;
        this.n6 = num6;
        this.n7 = num7;
        this.n8 = num8;
        this.n9 = num9;
        this.d10 = dig10;
        this.d11 = dig11;
    }
    
    /**
     *
     * @return
     */
    public String validacao()
    {
        multinum = (n1*10) + (n2 *9) + (n3 *8) + (n4 * 7) + (n5 * 6) + (n6 * 5)
                + (n7 * 4) + (n8 * 3) + (n9 * 2);
        
        resto = 11 -(multinum % 11);
        if(resto > 9){
            decpri = 0;
        }else
            decpri = resto;
        
        sm = (n1*11) + (n2 *10) + (n3 *9) + (n4 * 8) + (n5 * 7) + (n6 * 6)
                + (n7 * 5) + (n8 * 4) + (n9 * 3) + (decpri * 2);
        resto = 11 - (sm % 11);
        
        if(resto > 9){
            decseg = 0;
        }else
            decseg = resto;
        
        if(this.decpri == d10){
            if(this.decseg == d11){
                valido = "CPF Válido";
                return valido;
            }else
                invalido = "CPF Inválido";
                return invalido;
        }else
            invalido = "CPF Inválido";
            return invalido;
   
    }   
}