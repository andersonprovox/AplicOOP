/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

/**
 *
 * @author ander
 */
public class valEmp {
    private double salBruto;
    private double valDesc;
    private double valEmp;
    private int resultado = 2;
    
    public void recNum(double salario, double desconto, double emprestimo){
        this.salBruto = salario;
        this.valDesc = desconto;
        this.valEmp = emprestimo;
    }
    
    public int validando(){
        //int res = 2;
        double liquido;
        double parcela;
        liquido = this.salBruto - this.valDesc;
        parcela = liquido * 0.30;
        
        if (parcela < this.valEmp){
            this.resultado = 0;    
        }
        else if(parcela == this.valEmp){
            this.resultado = 1;            
        }
        else if (parcela > this.valEmp){
            this.resultado = 2;        
        }
        return this.resultado;
            
    }
}
