/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

/**
 *
 * @author carmo
 */
public class SomaFruta {
   private double numMaca;
   private double numGoiaba;
   private double numAmeixa;
   private double resMaca;
   private double resGoiaba;
   private double resAmeixa;
   public void recNum(double numM, double numG, double numA){
       this.numMaca = numM;
       this.numGoiaba = numG;
       this.numAmeixa = numA;
       
   }
   
   public double SomaMaca(){
       
       if(this.numMaca <= 2.0){
            resMaca = numMaca * 4.50;
       }
       else if(this.numMaca > 2.0 && this.numMaca <= 6.0){
           resMaca = numMaca * 3.90;
       }
       else
           resMaca = numMaca * 3.20;
       return resMaca;
   }
   
   public double SomaGoiaba(){
       
       if(this.numGoiaba <= 2.0){
            resGoiaba = numGoiaba * 2.50;
       }
       else if(this.numGoiaba > 2.0 && this.numGoiaba <= 6.0){
           resGoiaba = numGoiaba * 2.30;
       }
       else
           resGoiaba = numGoiaba * 1.90;
       return resGoiaba;
   }
   
   public double SomaAmeixa(){
       
       if(this.numAmeixa <= 2.0){
            resAmeixa = numAmeixa * 3.50;
       }
       else if(this.numAmeixa > 2.0 && this.numAmeixa <= 6.0){
           resAmeixa = numAmeixa * 3.20;
       }
       else
           resAmeixa = numAmeixa * 2.90;
       return resAmeixa;
   }
}
