/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

/**
 *
 * @author carmo
 */
public class somaCombustivel {
    private double numLitro;
    private double resGasosa;
    private double resAlcool;
    private double sumGasosa;
    private double sumAlcohol;
    public void recComb(double numLit){
        this.numLitro = numLit;
        
    }   
    
    public double sumGasosa(){
        sumGasosa = numLitro * 3.00;
        if(numLitro <= 20.0){
            resGasosa = sumGasosa - (sumGasosa * 0.04);
        }else
            resGasosa = sumGasosa - (sumGasosa * 0.06);
        return resGasosa;
    }
    public double sumAlcool(){
        sumAlcohol = numLitro * 2.00;
        if(numLitro <= 20.0){
            resAlcool = sumAlcohol - (sumAlcohol * 0.03);
        }else
            resAlcool = sumAlcohol - (sumAlcohol * 0.05);
        return resAlcool;
    }
}
