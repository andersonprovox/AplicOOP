/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

/**
 *
 * @author ander
 */
public class calculoSal {
    private double salBruto;
    private double descIR;
    private double descINSS;
    private double resSaliq;
    private double qtdHora;
    private double vlHora;
    
    public void recNum(double qHour, double vHour){
        this.qtdHora = qHour;
        this.vlHora = vHour;
    }
    
    public double somaSal(){
        this.salBruto = this.qtdHora * this.vlHora;
        
        if(this.salBruto > 500.00 && this.salBruto <= 1000.00){
            descINSS = salBruto * 0.08;   
            descIR = salBruto * 0.06;
        }
        else{
            descINSS = salBruto * 0.09;
            descIR = salBruto * 0.07;
        }
        resSaliq = salBruto - descINSS - descIR;
        return resSaliq;
    }
}
