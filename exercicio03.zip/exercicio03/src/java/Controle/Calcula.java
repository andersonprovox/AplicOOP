/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controle;

/**
 *
 * @author ander
 */
public class Calcula {
    private int num1;
    private int num2;
    private int resposta;
    
    public void recNum(int number1, int number2){
        
        this.num1 = number1;
        this.num2 = number2;
    }
    
    public int soma(){
        resposta = this.num1 + this.num2;
        return resposta;
    }
    public int subt(){
        resposta = this.num1 - this.num2;
        return resposta;
    }
    public int multi(){
        resposta = this.num1 * this.num2;
        return resposta;
    }
    public int div(){
        resposta = this.num1 * this.num2;
        return resposta;
        
    }
}
