/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

/**
 *
 * @author carmo
 */
public class lancheCusto {
    private int tHamburguer;
    private int tCheeseb;
    private int tFritas;
    private int tRefri;
    private double vHamburguer;
    private double vCheesb;
    private double vFritas;
    private double vRefri;
    private double totalGeral;
    
    public void recNum(int hamb, int cheese, int fritas, int refri){
        this.tHamburguer = hamb;
        this.tCheeseb = cheese;
        this.tFritas = fritas;
        this.tRefri = refri;
    }
    
    public double totalHamb(){
        this.vHamburguer = this.tHamburguer * 3.00;
        return this.vHamburguer;
    }
    
    public double totalCheese(){
        this.vCheesb = this.tCheeseb * 2.50;
        return this.vCheesb;
    }
    
    public double totalFritas(){
        this.vFritas = this.tFritas * 2.50;
        return this.vFritas;
    }
    
    public double totalRefri(){
        this.vRefri = this.tRefri * 1.00;
        return this.vRefri;
    }
    
    public double totalComanda(){
        this.totalGeral = this.vHamburguer + this.vCheesb + this.vFritas + this.vRefri;
        return this.totalGeral;
    }
}
